
from GA import GA


def readNet(file):
    f = open(file, "r")
    n = int(f.readline())
    net = {}
    net['noNodes'] = n
    mat = []
    for i in range(n):
        lineList = []
        line = f.readline()
        lineValues = line.split(',')
        for value in lineValues:
            lineList.append(int(value))
        mat.append(lineList)
    net['matrix'] = mat
    f.close()
    return net

# functia de fitness are ca argumente matricea de adiacenta si permutarea
#calculeaza valoarea drumului care trece prin toate orasele dat de permutare
def function(matrix, chr):
    val = 0
    for i in range(0, len(chr) - 1):
        val = val + matrix[chr[i] - 1][chr[i + 1] - 1]
    val = val + matrix[chr[len(chr) - 1] - 1][chr[0] - 1]
    return val

def Main():
    # net = readNet("easy1.txt")
    # net = readNet("easy2.txt")
    # net = readNet("easy3.txt")
    net = readNet("mediumF.txt")

    GAparam = {'popSize':200, 'noGen' : 500, 'pc' : 1.8, 'pm' : 1.1}
    problParam = {'net': net, 'function': function, 'noNodes':net['noNodes']}

    ga = GA(GAparam, problParam)
    ga.initialisation()
    ga.evaluation()

    for i in range(0, GAparam['noGen']):
        ga.oneGenerationElitism()
        print(ga.bestChromosome())

Main()
